/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

/**
 *
 * @author Gaby
 */
public enum Token {
    AND, ARRAY, BEGIN, BOOLEAN, BYTE, CASE, CHAR, CONST, DIV, DO, DOWNTO, ELSE, END, FALSE, FILE,
    FOR, FORWARD, FUNCTION, GOTO, IF, IN, INLINE, INT, LABEL, LONGINT, MOD, NIL, NOT, OF, OR, PACKED,
    PROCEDURE, PROGRAM, READ, REAL, RECORD, REPEAT, SET, SHORTINT, STRING, THEN, TO, TRUE, TYPE,
    UNTIL, VAR, WHILE, WITH, WRITE, XOR, ID, ERROR
}
